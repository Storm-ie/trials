# Input bindings are passed in via param block.
param([object] $QueueItem, $TriggerMetadata)

# Write out the queue message and insertion time to the information log.
Write-Information "PowerShell queue trigger function processed work item: $QueueItem"
Write-Host ($QueueItem | Format-List | Out-String)
Write-Information "Queue item insertion time: $($TriggerMetadata.InsertionTime)"

Write-Host "Starting..."

$ErrorActionPreference = "Stop"

# app settings
$global:SPO_TENANT_ID = $env:SPOTenantId
$global:SPO_TENANT = $env:SPOTenantName
$global:SPO_MANAGED_PATH = $env:SPOManagedPath
$global:SPO_SITE_COLLECTION_RELATIVE_URL = $env:SPOSiteCollectionRelativeUrl
$global:SPO_SITE_TEMPLATES_LIST_URL = $env:SPOSiteTemplatesListUrl
$global:SPO_PROVISIONING_REQUESTS_LIST_URL = $env:SPOProvisioningRequestsListUrl

# variables
$global:ITEM_ID = $QueueItem.ItemId
$global:SPO_ADMIN_SITE = "https://$SPO_TENANT-admin.sharepoint.com"
$global:SPO_TENANT_URL = "https://$SPO_TENANT.sharepoint.com"
$global:SPO_PROVISIONING_SITE = $SPO_TENANT_URL + $SPO_SITE_COLLECTION_RELATIVE_URL
$global:TEMPLATESPATH = "$PSScriptRoot/../../ProvisioningTemplates"

# Enable PnP trace log
Set-PnPTraceLog -On -Level:Debug -WriteToConsole


# import Utils
. $PSScriptRoot/Utils/Connect.ps1


# connect to SharePoint provisioning site
Connect-SPSite -SiteUrl $SPO_PROVISIONING_SITE

# get provisioning request item
$provisioningItem = (Get-PnPListItem -List $SPO_PROVISIONING_REQUESTS_LIST_URL -Id $ITEM_ID).FieldValues
Write-Information " Retrieved provisioning request item with Id: $ITEM_ID"
$templateFile = $provisioningItem.TemplateName

# update request progress - Creation
Set-PnPListItem -List $SPO_PROVISIONING_REQUESTS_LIST_URL -Identity $ITEM_ID -Values @{"Status" = "Creation"; }
Write-Information "Started processing request"


# create Templates folder outside of Function folder if not available yet
mkdir $TEMPLATESPATH -Force
# download template file to templates path - required at the moment as PnP PowerShell core does not support creating a tenant template from a string (at least for now)
Get-PnPFile -Url "$SPO_SITE_COLLECTION_RELATIVE_URL/$SPO_SITE_TEMPLATES_LIST_URL/$templateFile" -Path $TEMPLATESPATH -FileName $templateFile -AsFile -Force
Write-Information " Downloaded provisioning template file: $templateFile"


# get owners and members - force object to always be an array
$owners = @($provisioningItem["Owners"].Email)
$members = @($provisioningItem["Members"].Email)
$defaultOwnerUPN = $owners[0]

# connect to SharePoint admin portal
Connect-SPSite -SiteUrl $SPO_ADMIN_SITE

$siteCollectionUrl = "$SPO_TENANT_URL/$SPO_MANAGED_PATH/$($provisioningItem.WorkspaceAlias)"

# create group, site and team in advance so we can apply pre-provisioning changes if required
$groupAliasAlreadyUsed = Test-PnPMicrosoft365GroupAliasIsUsed -Alias $provisioningItem.WorkspaceAlias
if ($false -eq $groupAliasAlreadyUsed) {
    if ("Team" -eq $provisioningItem.WorkspaceType) {
        New-PnPMicrosoft365Group -DisplayName $provisioningItem.Title -Description $provisioningItem.WorkspaceDescription -MailNickname $provisioningItem.WorkspaceAlias -CreateTeam -Force -Owners $defaultOwnerUPN
    }
    else {
        New-PnPMicrosoft365Group -DisplayName $provisioningItem.Title -Description $provisioningItem.WorkspaceDescription -MailNickname $provisioningItem.WorkspaceAlias -Force -Owners $defaultOwnerUPN
    }
}
else {
    Write-Information "Group already exists! Configuring existing site and team."

    Write-Information " Workspace Type: $($provisioningItem.WorkspaceType)"
    if ("Team associated to a Site" -eq $provisioningItem.WorkspaceType) {
    
        # # connect to SharePoint existing site collection to add teams
        # Connect-SPSite -SiteUrl $siteCollectionUrl

        # #This command allows you to add a Teams team to an existing, Microsoft 365 group connected, site collection.
        # Add-PnPTeamsTeam

        # # connect to SharePoint admin portal
        # Connect-SPSite -SiteUrl $SPO_ADMIN_SITE
    }
}

# Enable custom scripts
if ($true -eq $provisioningItem["EnableSiteScripts"]) {   
    Write-Information "Enabling custom scripts..."
    Set-PnPSite -Identity $siteCollectionUrl -NoScriptSite $false
}

# template parameters
$templateParameters = @{
    "Title"       = $provisioningItem.Title
    "Alias"       = $provisioningItem.WorkspaceAlias
    "Description" = $provisioningItem.WorkspaceDescription
    "OwnerUPN"    = $defaultOwnerUPN
}
# merge required template parameters with optional parameters
if ($null -ne $provisioningItem.AdditionalTemplateParameters) {
    $additionalTemplateParameters = $provisioningItem.AdditionalTemplateParameters | ConvertFrom-Json -AsHashtable
    $templateParameters = $templateParameters + $additionalTemplateParameters
}

Write-Information "Parameters for provisioning template:"
Write-Host ($templateParameters | Format-List | Out-String)

if ("Site" -eq $provisioningItem.WorkspaceType) {
    # if the workspace type is Site, we need to remove all teams properties for Microsoft 365 group template to prevent some issues on the API
    $files = Get-ChildItem "$TEMPLATESPATH/$templateFile"
    foreach ($file in $files) { 
        (Get-Content $file.fullname) -replace 'xsi:type="pnp:TeamSite" ProvisioningId="TEAMSITE01"', 'xsi:type="pnp:CommunicationSite" ProvisioningId="MAIN"' -replace 'Alias="{parameter:Alias}"', 'Url="/sites/{parameter:Alias}"' -replace 'DisplayName="{parameter:Title}"', 'Owner="{parameter:OwnerUPN}"' -replace 'Teamify="true" HideTeamify="true" Language="1033"', '' -replace 'IsPublic="true"', '' -replace 'IsPublic="false"', '' |
        Set-Content $file.fullname
    }

    #removing pnp:Teams tag from .xml file and update it
    [xml]$Doc = Get-Content "$TEMPLATESPATH/$templateFile"
    $Doc.Provisioning.RemoveChild($Doc.Provisioning.Teams)
    $Doc.save("$TEMPLATESPATH/$templateFile")
}

# apply template
Invoke-PnPTenantTemplate -Path "$TEMPLATESPATH/$templateFile" -Parameters $templateParameters
Write-Information "Finished applying tenant template"

# connect to SharePoint admin portal again to complete additional operations
Connect-SPSite -SiteUrl $SPO_ADMIN_SITE
$group = Get-PnPMicrosoft365Group -Identity $provisioningItem.WorkspaceAlias -IncludeSiteUrl

# Update Owners
Write-Information "Adding owners..."
if ($owners.Count -gt 0 -and $null -ne $owners[0]) {
    Set-PnPMicrosoft365Group -Identity $group -Owners $owners
}
Write-Information "Adding members..."
if ($members.Count -gt 0 -and $null -ne $members[0]) {
    Set-PnPMicrosoft365Group -Identity $group -Members $members
}

Write-Information "Completing request..."

$channelURL = "";
if (("Team associated to a Site" -eq $provisioningItem.WorkspaceType) -or ("Team" -eq $provisioningItem.WorkspaceType)) {
    # Get Team and channel info
    $channel = Get-PnPTeamsChannel -Team $provisioningItem.WorkspaceAlias -Identity "General"
    $channelURL = "https://teams.microsoft.com/l/channel/$($channel.Id)/General?groupId=$($group.GroupId)&tenantId=$($TENANT_ID)"
}

# connect to SharePoint provisioning site to mark request item as complete
Connect-SPSite -SiteUrl $SPO_PROVISIONING_SITE

$workspaceType = $provisioningItem.WorkspaceType;
if ("Team associated to a Site" -eq $provisioningItem.WorkspaceType) {
    $workspaceType = "Team";
}

# update request - Provisioned
$newItemValues = @{
    "Status"            = "Provisioned"
    "SharePointSiteURL" = $group.SiteURL
    "TeamURL"           = $channelURL
    "WorkspaceType"     = $workspaceType
}
Set-PnPListItem -List $SPO_PROVISIONING_REQUESTS_LIST_URL -Identity $ITEM_ID -Values $newItemValues
Write-Information "Finished processing request"

Write-Information "Execution complete"
