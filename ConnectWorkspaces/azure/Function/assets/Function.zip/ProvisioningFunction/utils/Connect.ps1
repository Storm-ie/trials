# app settings
$global:ENVIRONMENT = $env:WEBSITE_SLOT_NAME
$global:AUTH_ID = $env:AuthId
$global:AUTH_SECRET = $env:AuthSecret
$global:AUTH_TYPE = $env:AuthType

function Connect-SPSite {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]$SiteUrl
    )
        
    begin {
        Write-Information "Connecting to $SiteUrl using $AUTH_TYPE..."        
    }
        
    process {

        Write-Information "Environment: $ENVIRONMENT"

        switch ($AUTH_TYPE) {
            "AzureADAppOnly" { 
                $CERTIFICATE = $env:Certificate # In Prod, contains the link to certificate from KeyVault. In Dev, contains the certificate name
                if ("Development" -eq $ENVIRONMENT) {
                    $certPath = Join-Path -Path $PSScriptRoot -ChildPath "../../../Certificates/$CERTIFICATE.pfx" -ErrorAction Stop
                    
                    $bytes = Get-Content $certPath -AsByteStream
                    $CERTIFICATE_BASE64_ENCODED = [Convert]::ToBase64String($bytes)
                    $securedPassword = ConvertTo-SecureString -AsPlainText $AUTH_SECRET -Force
                    Connect-PnPOnline -Url $SiteUrl -ClientId $AUTH_ID -Tenant "$SPO_TENANT.onmicrosoft.com" -CertificateBase64Encoded $CERTIFICATE_BASE64_ENCODED -CertificatePassword $securedPassword
                }
                else {
                    # Note: pass not required as cert in KeyVault already contains password
                    # $securedPassword = ConvertTo-SecureString -AsPlainText $AUTH_SECRET -Force
                    Connect-PnPOnline -Url $SiteUrl -ClientId $AUTH_ID -Tenant "$SPO_TENANT.onmicrosoft.com" -CertificateBase64Encoded $CERTIFICATE # -CertificatePassword $securedPassword
                }
            }
            "AzureADAppDelegated" {
                $APP_ID = $env:AppId # app setting only required for app delegated access. For other scenarios, client Id can be stored within AuthId
                Connect-PnPOnline -Url $SiteUrl -ClientId $APP_ID -Credentials (New-Object System.Management.Automation.PSCredential ($AUTH_ID, (ConvertTo-SecureString $AUTH_SECRET -AsPlainText -Force)))
            }
            Default {
                Write-Error "Error: Authentication type $AUTH_TYPE is not a valid option"
                exit
            }
        }
    }
    
    end {
        Write-Information "Connecting to $SiteUrl...[OK]"        
    }
}